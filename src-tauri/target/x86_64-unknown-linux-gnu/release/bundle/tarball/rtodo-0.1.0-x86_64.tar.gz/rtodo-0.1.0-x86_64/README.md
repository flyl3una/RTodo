# rtodo v0.1.0 (x86_64)

## 安装

1. 解压文件：
   tar -xzf rtodo-0.1.0-x86_64.tar.gz

2. 进入目录：
   cd rtodo-0.1.0-x86_64

3. 运行程序：
   ./rtodo

或者直接运行：
   ./rtodo-0.1.0-x86_64/rtodo

## 系统要求

- GTK 3
- WebKit2GTK
- libayatana-appindicator (可选，用于系统托盘)

### Ubuntu/Debian 安装依赖：
```bash
sudo apt install libgtk-3-0 libwebkit2gtk-4.1-0 libayatana-appindicator3-1
```

### Fedora/RHEL 安装依赖：
```bash
sudo dnf install gtk3 webkit2gtk3 libappindicator-gtk3
```

### Arch Linux 安装依赖：
```bash
sudo pacman -S gtk3 webkit2gtk libappindicator-gtk3
```

## 许可证

Copyright © 2025 RTodo Team. All rights reserved.
